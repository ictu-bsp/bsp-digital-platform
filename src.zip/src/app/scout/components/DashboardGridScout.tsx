// src/app/scout/components/DashboardGridScout.tsx

"use client";

import {
  CreditCard,
  Calendar,
  Megaphone,
  Award,
  FileBadge,
  ClipboardCheck,
} from "lucide-react";

import DashboardCard from "./DashboardCard";

export default function DashboardGridScout() {
  return (
    <section className="grid grid-cols-2 gap-4 p-4">

      <DashboardCard
        title="Membership Card"
        description="View your digital membership."
        href="/scout/membership"
        icon={<CreditCard size={28} />}
      />

      <DashboardCard
        title="Activities"
        description="View upcoming activities."
        href="/scout/activities"
        icon={<Calendar size={28} />}
      />

      <DashboardCard
        title="Announcements"
        description="Latest council updates."
        href="/scout/announcements"
        icon={<Megaphone size={28} />}
      />

      <DashboardCard
        title="Attendance"
        description="Track your participation."
        href="/scout/attendance"
        icon={<ClipboardCheck size={28} />}
      />

      <DashboardCard
        title="Achievements"
        description="Badges and awards."
        href="/scout/badges"
        icon={<Award size={28} />}
      />

      <DashboardCard
        title="Certificates"
        description="Download earned certificates."
        href="/scout/certificates"
        icon={<FileBadge size={28} />}
      />

    </section>
  );
}