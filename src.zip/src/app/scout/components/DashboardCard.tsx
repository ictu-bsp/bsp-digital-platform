//src/app/acout/components/DashboardCard.tsx

"use client";

import Link from "next/link";

interface DashboardCardProps {
  title: string;
  description: string;
  href: string;
  icon: React.ReactNode;
  disabled?: boolean;
}

export default function DashboardCard({
  title,
  description,
  href,
  icon,
  disabled = false,
}: DashboardCardProps) {
  const content = (
    <div
      className={`
        rounded-2xl
        border
        bg-white
        p-4
        shadow-sm
        transition

        ${
          disabled
            ? "cursor-not-allowed opacity-50"
            : "hover:shadow-md hover:-translate-y-1"
        }
      `}
    >
      <div className="mb-3 text-green-700">
        {icon}
      </div>

      <h3 className="font-semibold text-slate-900">
        {title}
      </h3>

      <p className="mt-1 text-sm text-slate-600">
        {description}
      </p>
    </div>
  );

  if (disabled) {
    return content;
  }

  return (
    <Link href={href}>
      {content}
    </Link>
  );
}