// src/app/scout/activities/[id]/page.tsx

import Link from "next/link";
import { redirect } from "next/navigation";

import Header from "@/app/scout/components/Header";
import BottomNav from "@/app/scout/components/BottomNav";
import JoinButton from "@/app/(public)/components/JoinButton";
import ActivityMetaBadges from "@/app/scout/activities/components/ActivityMetaBadges";

import { getCurrentUser } from "@/lib/auth/current-user";
import { getActivityById } from "@/services/activity.service";
import {
  getScoutByUserId,
  isScoutRegistered,
} from "@/services/activity-registration.service";

import type { PageProps } from "@/types/activity-details";

export default async function ActivityDetailPage({
  params,
}: PageProps) {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  const { id } = await params;

  // Get activity first
  const activity = await getActivityById(id);

  // Activity doesn't exist
  if (!activity) {
    return (
      <main className="min-h-screen bg-gradient-to-b from-white via-[#f7fdf8] to-[#e7f6ea] text-slate-900">
        <div className="mx-auto flex min-h-screen max-w-md flex-col">
          <Header
            userName={user.firstName}
            avatarUrl={user.avatarUrl ?? undefined}
          />

          <div className="flex-1 px-4 py-6">
            <p className="text-sm text-slate-600">
              Activity not found.
            </p>
          </div>

          <BottomNav />
        </div>
      </main>
    );
  }

  // Get scout profile
  const scout = await getScoutByUserId(user.id);

  // User isn't a scout yet
  if (!scout) {
    redirect("/scout/membership");
  }

  // Safe to check registration now
  const alreadyJoined = await isScoutRegistered(
    scout.id,
    activity.id
  );

  const formatDate = (date: Date) =>
    date.toLocaleString("en-PH", {
      dateStyle: "long",
      timeStyle: "short",
    });

  return (
    <main className="min-h-screen bg-gradient-to-b from-white via-[#f7fdf8] to-[#e7f6ea] text-slate-900">
      <div className="mx-auto flex min-h-screen max-w-md flex-col">
        <Header
          userName={user.firstName}
          avatarUrl={user.avatarUrl ?? undefined}
        />

        <div className="flex-1 overflow-y-auto pb-28">
          <div className="space-y-5 px-4 py-4">
            <Link
              href="/scout/activities"
              className="inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-white px-3 py-2 text-sm font-semibold text-emerald-800 shadow-sm"
            >
              <span aria-hidden="true">←</span>
              Back to activities
            </Link>

            <p className="text-sm font-semibold uppercase tracking-[0.3em] text-green-700">
              Scouting Activities
            </p>

            <h1 className="text-2xl font-bold leading-tight text-green-900">
              {activity.title}
            </h1>

            <div className="flex flex-col gap-6 lg:flex-row">
              <div className="flex-1 space-y-4">
                <p className="text-sm leading-7 text-slate-700">
                  {activity.description}
                </p>

                <ActivityMetaBadges
                  startDate={formatDate(activity.startDate)}
                  endDate={
                    activity.endDate
                      ? formatDate(activity.endDate)
                      : undefined
                  }
                  location={activity.location}
                  cost="Free"
                  registrationDeadline={
                    activity.registrationDeadline?.toISOString()
                  }
                />
              </div>

              <div className="flex items-center justify-center">
                <div className="flex h-32 w-32 items-center justify-center rounded-xl border-[10px] border-emerald-200 bg-emerald-100 shadow-inner">
                  <img
                    src={
                      activity.imageUrl ??
                      "/placeholder-banner-1.svg"
                    }
                    alt={activity.title}
                    className="h-20 w-20 rounded-xl object-cover"
                  />
                </div>
              </div>
            </div>

            <div className="pt-2">
              <JoinButton
                activityId={activity.id}
                registrationDeadline={activity.registrationDeadline}
                alreadyJoined={alreadyJoined}
              />
            </div>
          </div>
        </div>

        <BottomNav />
      </div>
    </main>
  );
}