// src/services/admin.service.ts

import { db } from "@/db";
import { count, eq, inArray, desc } from "drizzle-orm";
import { scoutApplications } from "@/db/schema";
import { assignMembershipIdToScout } from "@/services/application.service";

import {
  scouts,
  administrators,
  councils,
  users,
  roles,
  registrations,
  payments,
  regions,
  activities,
  activityRegistrations,
  adminUsers,
} from "@/db/schema";

import type {
  DashboardStats,
  AdminScoutRecord,
  AdministratorRecord,
} from "@/types/admin";

export type PendingRegistrationRecord = {
  id: string;
  scoutId: string;
  scoutIdNumber: string | null;

  fullName: string;
  email: string;
  birthdate: Date;
  sex: string;

  address: string | null;
  telephoneNumber: string | null;

  council: string;

  registrationYears: number;
  amount: number; // Estimated total (registrationYears * REGISTRATION_FEE_PER_YEAR) — payments table has no stored amount column
  startDate: string;
  endDate: string;
  status: string;

  isExistingScout: boolean;

  paymentStatus: string | null;
  paymentIntentId: string | null;

  extraDetails: {
    scoutingPosition?: string;
    advancementRank?: string;
    tenure?: string;
    region?: string;
    sponsoringInstitution?: string;
  };

  createdAt: Date;
};

function mapAdminScoutRecord(scout: {
  id: string;
  userId: string;
  scoutIdNumber: string | null;
  firstName: string;
  lastName: string;
  email: string;
  councilId: string;
  council: string;
  verificationStatus: string;
  createdAt: Date;
  updatedAt: Date;
}): AdminScoutRecord {
  return {
    id: scout.id,
    userId: scout.userId,
    scoutIdNumber: scout.scoutIdNumber,

    fullName: `${scout.lastName}, ${scout.firstName}`,

    email: scout.email,

    councilId: scout.councilId,
    council: scout.council,

    verificationStatus: scout.verificationStatus,

    createdAt: scout.createdAt,
    lastUpdated: scout.updatedAt,
  };
}

function mapAdministratorRecord(admin: {
  id: string;
  userId: string;
  firstName: string;
  lastName: string;
  email: string;
  roleId: string;
  role: string;
  position: string | null;
  office: string | null;
  createdAt: Date;
  updatedAt: Date;
}): AdministratorRecord {
  return {
    id: admin.id,

    userId: admin.userId,

    fullName: `${admin.lastName}, ${admin.firstName}`,

    email: admin.email,

    roleId: admin.roleId,

    role: admin.role,

    position: admin.position,

    office: admin.office,

    createdAt: admin.createdAt,

    lastUpdated: admin.updatedAt,
  };
}

export async function getDashboardStats(): Promise<DashboardStats> {
  const [scoutCount] = await db
    .select({ value: count() })
    .from(scouts);

  const [adminCount] = await db
    .select({ value: count() })
    .from(administrators);

  const [councilCount] = await db
    .select({ value: count() })
    .from(councils);

  return {
    totalScouts: scoutCount.value,
    totalAdministrators: adminCount.value,
    totalCouncils: councilCount.value,

    // Temporary placeholders until your teammate's modules are finished
    pendingPayments: 0,
    activeMembers: 0,
  };
}

export async function getAllScouts(): Promise<AdminScoutRecord[]> {
  const records = await db
    .select({
      id: scouts.id,
      userId: scouts.userId,
      scoutIdNumber: scouts.membershipNumber,

      firstName: users.firstName,
      lastName: users.lastName,
      email: users.email,

      councilId: councils.id,
      council: councils.name,

      verificationStatus: scouts.verificationStatus,

      createdAt: scouts.createdAt,
      updatedAt: scouts.updatedAt,
    })
    .from(scouts)
    .innerJoin(users, eq(scouts.userId, users.id))
    .innerJoin(councils, eq(scouts.councilId, councils.id));

  return records.map(mapAdminScoutRecord);
}

export async function getCouncilScouts(
  councilId: string
): Promise<AdminScoutRecord[]> {
  const records = await db
    .select({
      id: scouts.id,
      userId: scouts.userId,
      scoutIdNumber: scouts.membershipNumber,

      firstName: users.firstName,
      lastName: users.lastName,
      email: users.email,

      councilId: councils.id,
      council: councils.name,

      verificationStatus: scouts.verificationStatus,

      createdAt: scouts.createdAt,
      updatedAt: scouts.updatedAt,
    })
    .from(scouts)
    .innerJoin(users, eq(scouts.userId, users.id))
    .innerJoin(councils, eq(scouts.councilId, councils.id))
    .where(eq(scouts.councilId, councilId));

  return records.map(mapAdminScoutRecord);
}

export async function getScoutById(
  scoutId: string
): Promise<AdminScoutRecord | null> {
  const [record] = await db
    .select({
      id: scouts.id,
      userId: scouts.userId,
      scoutIdNumber: scouts.membershipNumber,

      firstName: users.firstName,
      lastName: users.lastName,
      email: users.email,

      councilId: councils.id,
      council: councils.name,

      verificationStatus: scouts.verificationStatus,

      createdAt: scouts.createdAt,
      updatedAt: scouts.updatedAt,
    })
    .from(scouts)
    .innerJoin(users, eq(scouts.userId, users.id))
    .innerJoin(councils, eq(scouts.councilId, councils.id))
    .where(eq(scouts.id, scoutId));

  if (!record) {
    return null;
  }

  return mapAdminScoutRecord(record);
}

export async function getAdministrators(): Promise<AdministratorRecord[]> {
  const records = await db
    .select({
      id: administrators.id,

      userId: administrators.userId,

      firstName: users.firstName,
      lastName: users.lastName,
      email: users.email,

      roleId: roles.id,
      role: roles.name,

      position: administrators.position,
      office: administrators.office,

      createdAt: administrators.createdAt,
      updatedAt: administrators.updatedAt,
    })
    .from(administrators)
    .innerJoin(users, eq(administrators.userId, users.id))
    .innerJoin(roles, eq(administrators.roleId, roles.id));

  return records.map(mapAdministratorRecord);
}

export async function getAdministratorById(
  administratorId: string
): Promise<AdministratorRecord | null> {
  const [record] = await db
    .select({
      id: administrators.id,

      userId: administrators.userId,

      firstName: users.firstName,
      lastName: users.lastName,
      email: users.email,

      roleId: roles.id,
      role: roles.name,

      position: administrators.position,
      office: administrators.office,

      createdAt: administrators.createdAt,
      updatedAt: administrators.updatedAt,
    })
    .from(administrators)
    .innerJoin(users, eq(administrators.userId, users.id))
    .innerJoin(roles, eq(administrators.roleId, roles.id))
    .where(eq(administrators.id, administratorId));

  if (!record) {
    return null;
  }

  return mapAdministratorRecord(record);
}

export async function getPendingRegistrations(): Promise<PendingRegistrationRecord[]> {
  const pendingRecords = await db
    .select({
      id: registrations.id,
      scoutId: registrations.scoutId,
      scoutIdNumber: scouts.membershipNumber,
      userId: scouts.userId,

      firstName: users.firstName,
      lastName: users.lastName,
      email: users.email,
      birthdate: users.birthdate,
      sex: users.sex,

      council: councils.name,

      registrationYears: registrations.registrationYears,
      startDate: registrations.startDate,
      endDate: registrations.endDate,
      status: registrations.status,
      remarks: registrations.remarks,
      createdAt: registrations.createdAt,
    })
    .from(registrations)
    .innerJoin(scouts, eq(registrations.scoutId, scouts.id))
    .innerJoin(users, eq(scouts.userId, users.id))
    .innerJoin(councils, eq(scouts.councilId, councils.id))
    .where(eq(registrations.status, "pending"));

  // Determine which scouts already have at least one "active" registration —
  // this pending one is a renewal for them, not a first-time registration.
  const activeRegs = await db
    .select({ scoutId: registrations.scoutId })
    .from(registrations)
    .where(eq(registrations.status, "active"));

  const activeScoutIds = new Set(activeRegs.map((r) => r.scoutId));

  // Fetch scoutApplications separately (not via leftJoin) to avoid
  // duplicate registration rows — same reasoning as the payments fix
  // below. A user can have more than one application (e.g. renewals),
  // so pick the most recent one per user.
  const pendingUserIds = pendingRecords.map((r) => r.userId);

  const relatedApplications = pendingUserIds.length
    ? await db
        .select({
          userId: scoutApplications.userId,
          address: scoutApplications.address,
          telephoneNumber: scoutApplications.telephoneNumber,
          scoutingPosition: scoutApplications.scoutingPosition,
          advancementRank: scoutApplications.advancementRank,
          tenure: scoutApplications.tenure,
          region: scoutApplications.region,
          sponsoringInstitution: scoutApplications.sponsoringInstitution,
          createdAt: scoutApplications.createdAt,
        })
        .from(scoutApplications)
        .where(inArray(scoutApplications.userId, pendingUserIds))
    : [];

  const latestApplicationByUserId = new Map<
    string,
    {
      address: string | null;
      telephoneNumber: string | null;
      scoutingPosition: string | null;
      advancementRank: string | null;
      tenure: number | null;
      region: string | null;
      sponsoringInstitution: string | null;
      createdAt: Date;
    }
  >();

  for (const application of relatedApplications) {
    const current = latestApplicationByUserId.get(application.userId);
    if (!current || application.createdAt > current.createdAt) {
      latestApplicationByUserId.set(application.userId, application);
    }
  }

  // Fetch payments separately (not via leftJoin) to avoid duplicate
  // registration rows when a registration has more than one payment
  // attempt (e.g. a failed GCash try followed by a successful Card retry).
  const pendingRegIds = pendingRecords.map((r) => r.id);

  const relatedPayments = pendingRegIds.length
    ? await db
        .select({
          registrationId: payments.registrationId,
          paymentStatus: payments.paymentStatus,
          paymentIntentId: payments.paymentIntentId,
          createdAt: payments.createdAt,
        })
        .from(payments)
        .where(inArray(payments.registrationId, pendingRegIds))
    : [];

  // Pick one payment per registration: prefer the most recent "paid" one,
  // falling back to the most recent payment of any status if none paid.
  const bestPaymentByRegId = new Map<
    string,
    { paymentStatus: string; paymentIntentId: string | null; createdAt: Date }
  >();

  for (const payment of relatedPayments) {
    const current = bestPaymentByRegId.get(payment.registrationId);

    if (!current) {
      bestPaymentByRegId.set(payment.registrationId, payment);
      continue;
    }

    const currentIsPaid = current.paymentStatus === "paid";
    const candidateIsPaid = payment.paymentStatus === "paid";

    if (candidateIsPaid && !currentIsPaid) {
      // A paid payment always outranks a non-paid one, regardless of date.
      bestPaymentByRegId.set(payment.registrationId, payment);
    } else if (candidateIsPaid === currentIsPaid && payment.createdAt > current.createdAt) {
      // Same "paid-ness" — keep whichever is more recent.
      bestPaymentByRegId.set(payment.registrationId, payment);
    }
  }

  return pendingRecords
    .filter((record) => {
      // Only show registrations that have actually been paid for.
      const bestPayment = bestPaymentByRegId.get(record.id);
      return bestPayment?.paymentStatus === "paid";
    })
    .map((record) => {
      const bestPayment = bestPaymentByRegId.get(record.id);
      const application = latestApplicationByUserId.get(record.userId);

      const extraDetails: PendingRegistrationRecord["extraDetails"] = {
        scoutingPosition: application?.scoutingPosition ?? undefined,
        advancementRank: application?.advancementRank ?? undefined,
        tenure:
          application?.tenure !== null && application?.tenure !== undefined
            ? String(application.tenure)
            : undefined,
        region: application?.region ?? undefined,
        sponsoringInstitution: application?.sponsoringInstitution ?? undefined,
      };

      return {
        id: record.id,
        scoutId: record.scoutId,
        scoutIdNumber: record.scoutIdNumber,

        fullName: `${record.lastName}, ${record.firstName}`,
        email: record.email,
        birthdate: record.birthdate,
        sex: record.sex,

        address: application?.address ?? null,
        telephoneNumber: application?.telephoneNumber ?? null,

        council: record.council,
        registrationYears: record.registrationYears,
        amount: record.registrationYears * REGISTRATION_FEE_PER_YEAR,
        startDate: record.startDate,
        endDate: record.endDate,
        status: record.status,
        isExistingScout: activeScoutIds.has(record.scoutId),

        paymentStatus: bestPayment?.paymentStatus ?? null,
        paymentIntentId: bestPayment?.paymentIntentId ?? null,

        extraDetails,

        createdAt: record.createdAt,
      };
    });
}

export async function approveMembershipReview(
  registrationId: string
) {
  const [registration] = await db
    .select({ id: registrations.id })
    .from(registrations)
    .where(eq(registrations.id, registrationId));

  if (!registration) {
    throw new Error("Registration not found.");
  }

  // Membership stage only: mark reviewed, hand off to Finance.
  // Does NOT activate the registration, promote the user, or
  // issue a membership number — that happens in
  // verifyAndActivateRegistration() once Finance verifies payment.
  await db
    .update(registrations)
    .set({
      status: "membership_approved",
      updatedAt: new Date(),
    })
    .where(eq(registrations.id, registrationId));
}

export async function verifyAndActivateRegistration(
  registrationId: string
) {
  // Find the registration
  const [registration] = await db
    .select({
      scoutId: registrations.scoutId,
    })
    .from(registrations)
    .where(eq(registrations.id, registrationId));

  if (!registration) {
    throw new Error("Registration not found.");
  }

  // Find the scout (including councilId to pass down to assignMembershipIdToScout)
  const [scout] = await db
    .select({
      id: scouts.id,
      userId: scouts.userId,
      councilId: scouts.councilId,
      membershipNumber: scouts.membershipNumber,
    })
    .from(scouts)
    .where(eq(scouts.id, registration.scoutId));

  if (!scout) {
    throw new Error("Scout record not found.");
  }

  // Activate registration
  await db
    .update(registrations)
    .set({
      status: "active",
      updatedAt: new Date(),
    })
    .where(eq(registrations.id, registrationId));

  // Promote user
  await db
    .update(users)
    .set({
      role: "SCOUT",
      updatedAt: new Date(),
    })
    .where(eq(users.id, scout.userId));

  // Retain existing membership number OR generate a new structured ID
  const membershipNumber =
    scout.membershipNumber ??
    (await assignMembershipIdToScout(scout.id, scout.councilId));

  await db
    .update(scouts)
    .set({
      status: "ACTIVE",
      verificationStatus: "active",
      membershipNumber,
      approvedAt: new Date(),
      updatedAt: new Date(),
    })
    .where(eq(scouts.id, scout.id));

  // Mirror the approval onto the scout's latest scoutApplications row.
  const [latestApplication] = await db
    .select({ id: scoutApplications.id })
    .from(scoutApplications)
    .where(eq(scoutApplications.userId, scout.userId))
    .orderBy(desc(scoutApplications.createdAt))
    .limit(1);

  if (latestApplication) {
    await db
      .update(scoutApplications)
      .set({
        status: "APPROVED",
        reviewedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(scoutApplications.id, latestApplication.id));
  } else {
    // Previously this silently did nothing, leaving scout_applications
    // out of sync with no trace. Log loudly so it's visible instead of
    // hidden — a scout being finance-activated should always have an
    // application row backing it.
    console.error(
      `[verifyAndActivateRegistration] No scoutApplications row found for userId ${scout.userId} (registrationId ${registrationId}). Scout was activated but scout_applications was not updated.`
    );
  }
}

export async function getRegistrationsAwaitingFinance(): Promise<PendingRegistrationRecord[]> {
  const records = await db
    .select({
      id: registrations.id,
      scoutId: registrations.scoutId,
      scoutIdNumber: scouts.membershipNumber,
      userId: scouts.userId,

      firstName: users.firstName,
      lastName: users.lastName,
      email: users.email,
      birthdate: users.birthdate,
      sex: users.sex,

      council: councils.name,

      registrationYears: registrations.registrationYears,
      startDate: registrations.startDate,
      endDate: registrations.endDate,
      status: registrations.status,
      remarks: registrations.remarks,
      createdAt: registrations.createdAt,
    })
    .from(registrations)
    .innerJoin(scouts, eq(registrations.scoutId, scouts.id))
    .innerJoin(users, eq(scouts.userId, users.id))
    .innerJoin(councils, eq(scouts.councilId, councils.id))
    .where(eq(registrations.status, "membership_approved"));

  const activeRegs = await db
    .select({ scoutId: registrations.scoutId })
    .from(registrations)
    .where(eq(registrations.status, "active"));

  const activeScoutIds = new Set(activeRegs.map((r) => r.scoutId));

  const userIds = records.map((r) => r.userId);

  const relatedApplications = userIds.length
    ? await db
        .select({
          userId: scoutApplications.userId,
          address: scoutApplications.address,
          telephoneNumber: scoutApplications.telephoneNumber,
          scoutingPosition: scoutApplications.scoutingPosition,
          advancementRank: scoutApplications.advancementRank,
          tenure: scoutApplications.tenure,
          region: scoutApplications.region,
          sponsoringInstitution: scoutApplications.sponsoringInstitution,
          createdAt: scoutApplications.createdAt,
        })
        .from(scoutApplications)
        .where(inArray(scoutApplications.userId, userIds))
    : [];

  const latestApplicationByUserId = new Map<
    string,
    {
      address: string | null;
      telephoneNumber: string | null;
      scoutingPosition: string;
      advancementRank: string;
      tenure: number;
      region: string;
      sponsoringInstitution: string | null;
      createdAt: Date;
    }
  >();

  for (const application of relatedApplications) {
    const current = latestApplicationByUserId.get(application.userId);
    if (!current || application.createdAt > current.createdAt) {
      latestApplicationByUserId.set(application.userId, application);
    }
  }

  const regIds = records.map((r) => r.id);

  const relatedPayments = regIds.length
    ? await db
        .select({
          registrationId: payments.registrationId,
          paymentStatus: payments.paymentStatus,
          paymentIntentId: payments.paymentIntentId,
          createdAt: payments.createdAt,
        })
        .from(payments)
        .where(inArray(payments.registrationId, regIds))
    : [];

  const bestPaymentByRegId = new Map<string, { paymentStatus: string; paymentIntentId: string | null; createdAt: Date }>();

  for (const payment of relatedPayments) {
    const current = bestPaymentByRegId.get(payment.registrationId);

    if (!current) {
      bestPaymentByRegId.set(payment.registrationId, payment);
      continue;
    }

    const currentIsPaid = current.paymentStatus === "paid";
    const candidateIsPaid = payment.paymentStatus === "paid";

    if (candidateIsPaid && !currentIsPaid) {
      bestPaymentByRegId.set(payment.registrationId, payment);
    } else if (candidateIsPaid === currentIsPaid && payment.createdAt > current.createdAt) {
      bestPaymentByRegId.set(payment.registrationId, payment);
    }
  }

  return records.map((record) => {
    const bestPayment = bestPaymentByRegId.get(record.id);
    const application = latestApplicationByUserId.get(record.userId);

    const extraDetails: PendingRegistrationRecord["extraDetails"] = {
      scoutingPosition: application?.scoutingPosition,
      advancementRank: application?.advancementRank,
      tenure:
        application?.tenure !== undefined
          ? String(application.tenure)
          : undefined,
      region: application?.region,
      sponsoringInstitution: application?.sponsoringInstitution ?? undefined,
    };

    return {
      id: record.id,
      scoutId: record.scoutId,
      scoutIdNumber: record.scoutIdNumber,

      fullName: `${record.lastName}, ${record.firstName}`,
      email: record.email,
      birthdate: record.birthdate,
      sex: record.sex,

      address: application?.address ?? null,
      telephoneNumber: application?.telephoneNumber ?? null,

      council: record.council,
      registrationYears: record.registrationYears,
      amount: record.registrationYears * REGISTRATION_FEE_PER_YEAR,
      startDate: record.startDate,
      endDate: record.endDate,
      status: record.status,

      isExistingScout: activeScoutIds.has(record.scoutId),

      paymentStatus: bestPayment?.paymentStatus ?? null,
      paymentIntentId: bestPayment?.paymentIntentId ?? null,

      extraDetails,

      createdAt: record.createdAt,
    };
  });
}

export async function rejectRegistration(
  registrationId: string,
  feedback: string
) {
  const [existing] = await db
    .select({
      remarks: registrations.remarks,
      scoutId: registrations.scoutId,
    })
    .from(registrations)
    .where(eq(registrations.id, registrationId));

  let remarksData: Record<string, unknown> = {};
  if (existing?.remarks) {
    try {
      remarksData = JSON.parse(existing.remarks);
    } catch {
      remarksData = {};
    }
  }

  remarksData.rejectionFeedback = feedback;

  await db
    .update(registrations)
    .set({
      status: "cancelled",
      remarks: JSON.stringify(remarksData),
      updatedAt: new Date(),
    })
    .where(eq(registrations.id, registrationId));

  // Mirror the rejection onto the scout's latest scoutApplications row
  if (existing?.scoutId) {
    const [scout] = await db
      .select({ userId: scouts.userId })
      .from(scouts)
      .where(eq(scouts.id, existing.scoutId));

    if (scout) {
      const [latestApplication] = await db
        .select({ id: scoutApplications.id })
        .from(scoutApplications)
        .where(eq(scoutApplications.userId, scout.userId))
        .orderBy(desc(scoutApplications.createdAt))
        .limit(1);

      if (latestApplication) {
        await db
          .update(scoutApplications)
          .set({
            status: "REJECTED",
            remarks: feedback,
            reviewedAt: new Date(),
            updatedAt: new Date(),
          })
          .where(eq(scoutApplications.id, latestApplication.id));
      }
    }
  }
}

export async function assignAdministratorRole(
  administratorId: string,
  roleId: string
) {
  throw new Error("Not implemented yet.");
}

export async function removeAdministrator(
  administratorId: string
) {
  throw new Error("Not implemented yet.");
}

// -------------------------------------------------
// Reports
// -------------------------------------------------

const REGISTRATION_FEE_PER_YEAR = 50; // TODO: confirm against register/page.tsx's FEE_PER_YEAR (currently 100 there — mismatch flagged for Reuben)

export async function getRegistrationStatusBreakdown() {
  const rows = await db
    .select({
      status: registrations.status,
      value: count(),
    })
    .from(registrations)
    .groupBy(registrations.status);

  return rows;
}

export async function getPaymentTotals() {
  const statusCounts = await db
    .select({
      status: payments.paymentStatus,
      value: count(),
    })
    .from(payments)
    .groupBy(payments.paymentStatus);

  // Estimated pesos collected: only counts payments with status "paid",
  // joined back to their registration's registrationYears, multiplied by
  // the flat per-year fee. This is an ESTIMATE, not a stored actual
  // amount — payments table has no amount column.
  const paidWithYears = await db
    .select({
      registrationYears: registrations.registrationYears,
    })
    .from(payments)
    .innerJoin(registrations, eq(payments.registrationId, registrations.id))
    .where(eq(payments.paymentStatus, "paid"));

  const estimatedTotalCollected = paidWithYears.reduce(
    (sum, row) => sum + row.registrationYears * REGISTRATION_FEE_PER_YEAR,
    0
  );

  return {
    statusCounts,
    estimatedTotalCollected,
    feePerYearUsed: REGISTRATION_FEE_PER_YEAR,
  };
}

export async function getCouncilRegionBreakdown() {
  const councilCounts = await db
    .select({
      council: councils.name,
      value: count(),
    })
    .from(scouts)
    .innerJoin(councils, eq(scouts.councilId, councils.id))
    .groupBy(councils.name);

  // Left join regions since councils.regionId is nullable — councils
  // without a region assigned yet fall into an "Unassigned" bucket.
  const regionCounts = await db
    .select({
      region: regions.name,
      value: count(),
    })
    .from(scouts)
    .innerJoin(councils, eq(scouts.councilId, councils.id))
    .leftJoin(regions, eq(councils.regionId, regions.id))
    .groupBy(regions.name);

  const normalizedRegionCounts = regionCounts.map((row) => ({
    region: row.region ?? "Unassigned",
    value: row.value,
  }));

  return {
    councilCounts,
    regionCounts: normalizedRegionCounts,
  };
}

export async function getScoutRankBreakdown() {
  const rows = await db
    .select({
      rank: scouts.rank,
      value: count(),
    })
    .from(scouts)
    .groupBy(scouts.rank);

  return rows;
}

export async function getSexBreakdown() {



  const rows = await db
    .select({
      sex: users.sex,
      value: count(),
    })
    .from(scouts)
    .innerJoin(users, eq(scouts.userId, users.id))
    .groupBy(users.sex);

  return rows;
}

export async function getActivityParticipationStats() {
  const rows = await db
    .select({
      activityId: activities.id,
      title: activities.title,
      startDate: activities.startDate,
      value: count(activityRegistrations.id),
    })
    .from(activities)
    .leftJoin(
      activityRegistrations,
      eq(activityRegistrations.activityId, activities.id)
    )
    .groupBy(activities.id, activities.title, activities.startDate)
    .orderBy(desc(activities.startDate));

  return rows;
}


// -------------------------------------------------
// Officers (adminUsers table — the real, live admin accounts
// table used by src/app/api/admin/login/route.ts). Not to be
// confused with the older `administrators`/`roles` tables used
// above in getAdministrators()/getAdministratorById() — those
// are a separate, stale path.
// -------------------------------------------------

export type AdminUserRecord = {
  id: string;
  username: string;
  fullName: string;
  role: string;
  active: boolean;
  council: string;
  lastLoginAt: Date | null;
  createdAt: Date;
};

export async function getAdminUsers(): Promise<AdminUserRecord[]> {
  const records = await db
    .select({
      id: adminUsers.id,
      username: adminUsers.username,
      fullName: adminUsers.fullName,
      role: adminUsers.role,
      active: adminUsers.active,
      council: councils.name,
      lastLoginAt: adminUsers.lastLoginAt,
      createdAt: adminUsers.createdAt,
    })
    .from(adminUsers)
    .innerJoin(councils, eq(adminUsers.councilId, councils.id));

  return records;
}